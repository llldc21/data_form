<?php
    $conexao = new mysqli("llldc21.profrodolfo.com:3306","llldc21","91555830Luc@s","llldc21_data_form");
    $conexao->query("SET NAMES 'utf8'");
    $conexao->query('SET character_set_connection=utf8');
    $conexao->query('SET character_set_client=utf8');
    $conexao->query('SET character_set_results=utf8');
?>